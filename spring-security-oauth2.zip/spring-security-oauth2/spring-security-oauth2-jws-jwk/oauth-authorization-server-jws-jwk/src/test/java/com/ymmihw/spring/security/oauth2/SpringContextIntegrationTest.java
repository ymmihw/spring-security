package com.ymmihw.spring.security.oauth2;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringContextIntegrationTest {

  @Test
  public void whenContextInitializes_thenNoExceptionsTriggered() throws Exception {

  }
}
